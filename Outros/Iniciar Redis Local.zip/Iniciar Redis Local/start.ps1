$redisPassword = [System.Guid]::NewGuid().ToString("N")

docker run -d --rm --name n8n-redis -p 6379:6379 redis:latest redis-server --requirepass $redisPassword

Write-Host "Redis container 'n8n-redis' está rodando."
Write-Host "Credenciais:"
Write-Host "  User: default"
Write-Host "  Host: host.docker.internal"
Write-Host "  Porta: 6379"
Write-Host "  Senha: $redisPassword"
