REDIS_PASSWORD=$(openssl rand -hex 16)

docker run -d --rm --name n8n-redis -p 6379:6379 redis:latest redis-server --requirepass $REDIS_PASSWORD

HOST_IP=$(hostname -I | awk '{print $1}')

echo "Redis container 'n8n-redis' está rodando."
echo "Credenciais:"
echo "  User: default"
echo "  Host: $HOST_IP"
echo "  Porta: 6379"
echo "  Senha: $REDIS_PASSWORD"
