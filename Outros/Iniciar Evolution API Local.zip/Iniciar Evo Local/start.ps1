Write-Host "Digite a senha do Postgres (POSTGRES_PASSWORD):"
$POSTGRES_PASSWORD = Read-Host

Write-Host "Digite o email do pgAdmin (PGADMIN_DEFAULT_EMAIL):"
$PGADMIN_DEFAULT_EMAIL = Read-Host

$env:POSTGRES_PASSWORD = $POSTGRES_PASSWORD
$env:PGADMIN_DEFAULT_EMAIL = $PGADMIN_DEFAULT_EMAIL

$apiKey = [System.Guid]::NewGuid().ToString("N")

$env:AUTHENTICATION_API_KEY = $apiKey

docker-compose up -d

Write-Host "Evolution API está rodando em: http://localhost:8080"
Write-Host "Copie sua chave de API agora! Ela não será exibida novamente."
Write-Host "Chave de API (senha) da Evolution: $apiKey"
