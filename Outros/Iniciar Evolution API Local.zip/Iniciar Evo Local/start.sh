echo "Digite a senha do Postgres (POSTGRES_PASSWORD):"
read POSTGRES_PASSWORD

echo "Digite o email do pgAdmin (PGADMIN_DEFAULT_EMAIL):"
read PGADMIN_DEFAULT_EMAIL

export POSTGRES_PASSWORD
export PGADMIN_DEFAULT_EMAIL

API_KEY=$(openssl rand -hex 16)

export AUTHENTICATION_API_KEY=$API_KEY

docker-compose up -d

echo "Evolution API está rodando em: http://localhost:8080"
echo "Copie sua chave de API agora! Ela não será exibida novamente."
echo "Chave de API (senha) da Evolution: $API_KEY"
